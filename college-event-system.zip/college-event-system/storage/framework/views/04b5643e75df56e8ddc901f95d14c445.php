<?php $__env->startSection('content'); ?>
<h2>Upload Media</h2>
<form method="POST" action="<?php echo e(route('gallery.upload')); ?>" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
  <div class="mb-2">
    <label>Event</label>
    <input type="number" name="event_id" class="form-control" required>
  </div>
  <div class="mb-2">
    <label>File</label>
    <input type="file" name="file" class="form-control" required>
  </div>
  <div class="mb-2">
    <label>Caption</label>
    <input type="text" name="caption" class="form-control">
  </div>
  <div class="mb-2">
    <label>Subcategory</label>
    <select name="subcategory_id" class="form-control">
      <option value="">None</option>
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <optgroup label="<?php echo e($cat->name); ?>">
          <?php $__currentLoopData = $cat->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($sub->id); ?>"><?php echo e($sub->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </optgroup>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>
  <button class="btn btn-primary">Upload</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\college-event-system\resources\views/gallery/upload.blade.php ENDPATH**/ ?>