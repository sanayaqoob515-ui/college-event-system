<?php $__env->startSection('content'); ?>
<h2>Contact Us</h2>
<p>For support or queries, email us at <a href="mailto:support@collegeevents.com">support@collegeevents.com</a> or call +92-123-4567890.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\college-event-system\resources\views/contact.blade.php ENDPATH**/ ?>