<?php $__env->startSection('content'); ?>
<h2>Moderate Feedback</h2>
<?php $__currentLoopData = $feedbacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="border p-2 mb-2">
    <strong><?php echo e($fb->user->name ?? ''); ?></strong> - Rating: <?php echo e($fb->rating); ?><br>
    <small><?php echo e($fb->created_at->diffForHumans()); ?></small>
    <p><?php echo e($fb->comment); ?></p>
    <form method="POST" action="#" style="display:inline"><?php echo csrf_field(); ?><button class="btn btn-sm btn-danger">Delete</button></form>
  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\college-event-system\resources\views/admin/feedbacks.blade.php ENDPATH**/ ?>