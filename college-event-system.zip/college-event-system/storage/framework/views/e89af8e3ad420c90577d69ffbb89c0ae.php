<?php $__env->startSection('content'); ?>
<h2>All Users</h2>
<table class="table">
  <tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Actions</th></tr>
  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($user->name); ?></td>
      <td><?php echo e($user->email); ?></td>
      <td>
        <form method="POST" action="<?php echo e(route('admin.updateRole', $user->id)); ?>">
          <?php echo csrf_field(); ?>
          <select name="role" onchange="this.form.submit()">
            <option value="student" <?php if($user->role=='student'): ?> selected <?php endif; ?>>Student</option>
            <option value="organizer" <?php if($user->role=='organizer'): ?> selected <?php endif; ?>>Organizer</option>
            <option value="admin" <?php if($user->role=='admin'): ?> selected <?php endif; ?>>Admin</option>
          </select>
        </form>
      </td>
      <td><?php echo e($user->status ?? 'active'); ?></td>
      <td>
        <form method="POST" action="<?php echo e(route('admin.suspend', $user->id)); ?>" style="display:inline"><?php echo csrf_field(); ?><button class="btn btn-sm btn-warning">Suspend</button></form>
        <form method="POST" action="<?php echo e(route('admin.delete', $user->id)); ?>" style="display:inline"><?php echo csrf_field(); ?><button class="btn btn-sm btn-danger">Delete</button></form>
      </td>
    </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\college-event-system\resources\views/admin/users.blade.php ENDPATH**/ ?>