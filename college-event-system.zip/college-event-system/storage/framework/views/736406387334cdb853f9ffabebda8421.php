<?php $__env->startSection('content'); ?>
<h2>Participant Dashboard</h2>
<h4>My Registrations</h4>
<ul>
  <?php $__currentLoopData = $regs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>
      <?php echo e($reg->event->title); ?> - Status: <?php echo e($reg->status); ?>

      <form method="POST" action="<?php echo e(route('registrations.cancel', $reg->id)); ?>" style="display:inline">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button class="btn btn-sm btn-danger">Cancel</button>
      </form>
    </li>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<h4>Join Waitlist for Full Events</h4>
<form method="POST" action="<?php echo e(route('events.waitlist', ['id' => 0])); ?>" onsubmit="event.preventDefault(); var id = prompt('Enter Event ID to join waitlist:'); if(id) { this.action = this.action.replace('/0', '/' + id); this.submit(); }">
    <?php echo csrf_field(); ?>
    <button class="btn btn-sm btn-warning">Join Waitlist</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\college-event-system\resources\views/dashboards/participant.blade.php ENDPATH**/ ?>