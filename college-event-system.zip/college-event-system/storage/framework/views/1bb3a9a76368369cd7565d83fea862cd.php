<?php $__env->startSection('content'); ?>
<form method="GET" action="<?php echo e(route('home')); ?>" class="mb-3">
  <div class="row">
    <div class="col-md-2"><input type="text" name="q" class="form-control" placeholder="Keyword" value="<?php echo e(request('q')); ?>"></div>
    <div class="col-md-2"><input type="text" name="category" class="form-control" placeholder="Category" value="<?php echo e(request('category')); ?>"></div>
    <div class="col-md-2"><input type="text" name="department" class="form-control" placeholder="Department" value="<?php echo e(request('department')); ?>"></div>
    <div class="col-md-2"><input type="date" name="date_from" class="form-control" value="<?php echo e(request('date_from')); ?>"></div>
    <div class="col-md-2"><input type="date" name="date_to" class="form-control" value="<?php echo e(request('date_to')); ?>"></div>
    <div class="col-md-2"><button class="btn btn-primary w-100">Search</button></div>
  </div>
</form>

<?php if(isset($events)): ?>
  <div class="list-group">
    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <a href="<?php echo e(route('events.show', $event->id)); ?>" class="list-group-item list-group-item-action">
        <div class="d-flex w-100 justify-content-between">
          <h5 class="mb-1"><?php echo e($event->title); ?></h5>
          <small><?php echo e($event->date); ?></small>
        </div>
        <p class="mb-1"><?php echo e(Str::limit($event->description, 120)); ?></p>
        <small>Venue: <?php echo e($event->venue); ?> | Slots: <span id="slots-<?php echo e($event->id); ?>"><?php echo e($event->max_participants - $event->seats_booked); ?></span> / <?php echo e($event->max_participants); ?></small>
      </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <div class="mt-3"><?php echo e($events->links() ?? ''); ?></div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\college-event-system\resources\views/events/index.blade.php ENDPATH**/ ?>