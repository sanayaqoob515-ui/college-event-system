<?php $__env->startSection('content'); ?>
<h2>Moderate Media</h2>
<?php $__currentLoopData = $media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="border p-2 mb-2">
    <img src="/storage/<?php echo e($m->file_url); ?>" width="100"> <?php echo e($m->caption); ?>

    <form method="POST" action="#" style="display:inline"><?php echo csrf_field(); ?><button class="btn btn-sm btn-danger">Delete</button></form>
  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\college-event-system\resources\views/admin/media.blade.php ENDPATH**/ ?>