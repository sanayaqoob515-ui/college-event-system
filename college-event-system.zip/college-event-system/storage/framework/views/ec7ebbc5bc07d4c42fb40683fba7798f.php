<?php $__env->startSection('content'); ?>
<h2>About Us</h2>
<p>This platform is designed to manage and promote college events, registrations, certificates, and more. It connects students, organizers, and administrators for a seamless event experience.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\college-event-system\resources\views/about.blade.php ENDPATH**/ ?>