<?php $__env->startSection('content'); ?>
<h2>Gallery</h2>
<form method="GET" class="mb-3">
	<div class="row">
		<div class="col-md-4">
			<select name="category" class="form-control" onchange="this.form.submit()">
				<option value="">All Categories</option>
				<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($cat->id); ?>" <?php if($selectedCategory==$cat->id): ?> selected <?php endif; ?>><?php echo e($cat->name); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
		</div>
		<div class="col-md-4">
			<select name="subcategory" class="form-control" onchange="this.form.submit()">
				<option value="">All Subcategories</option>
				<?php if($selectedCategory): ?>
					<?php $__currentLoopData = $categories->where('id',$selectedCategory)->first()->subcategories ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($sub->id); ?>" <?php if($selectedSubcategory==$sub->id): ?> selected <?php endif; ?>><?php echo e($sub->name); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php else: ?>
					<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php $__currentLoopData = $cat->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($sub->id); ?>" <?php if($selectedSubcategory==$sub->id): ?> selected <?php endif; ?>><?php echo e($cat->name); ?> - <?php echo e($sub->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>
			</select>
		</div>
		<div class="col-md-4">
			<button class="btn btn-primary">Filter</button>
		</div>
	</div>
</form>
<div class='row'>
<?php $__currentLoopData = $media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class='col-md-3 mb-3'>
		<img src="<?php echo e(asset('storage/' . $m->file_url)); ?>" class='img-fluid'>
		<p><?php echo e($m->caption); ?></p>
		<?php if($m->subcategory): ?>
			<small class="text-muted"><?php echo e($m->subcategory->category->name ?? ''); ?> / <?php echo e($m->subcategory->name); ?></small>
		<?php endif; ?>
	</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\college-event-system\resources\views/gallery/index.blade.php ENDPATH**/ ?>