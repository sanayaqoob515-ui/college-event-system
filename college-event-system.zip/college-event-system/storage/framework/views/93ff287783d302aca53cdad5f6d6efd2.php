<?php $__env->startSection('content'); ?>
<h2>Organizer Dashboard</h2>
<h4>Your Events</h4>
<ul>
  <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>
      <?php echo e($ev->title); ?> - Status: <?php echo e($ev->status); ?> | Slots: <?php echo e($ev->max_participants - $ev->seats_booked); ?>/<?php echo e($ev->max_participants); ?>

      <form method="POST" action="<?php echo e(route('organizer.updateSlots', $ev->id)); ?>" style="display:inline">
        <?php echo csrf_field(); ?>
        <input type="number" name="max_participants" value="<?php echo e($ev->max_participants); ?>" min="1" style="width:80px">
        <button class="btn btn-sm btn-info">Update Slots</button>
      </form>
    </li>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\college-event-system\resources\views/dashboards/organizer.blade.php ENDPATH**/ ?>