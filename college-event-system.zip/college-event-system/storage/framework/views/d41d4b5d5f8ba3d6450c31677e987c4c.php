<?php $__env->startSection('content'); ?>
<h2>Admin Dashboard</h2>
<h4>Pending Events</h4>
<ul>
  <?php $__currentLoopData = $pending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($ev->title); ?> 
      <form action="/admin/events/<?php echo e($ev->id); ?>/approve" method="POST" style="display:inline"><?php echo csrf_field(); ?><button class="btn btn-sm btn-success">Approve</button></form>
      <form action="/admin/events/<?php echo e($ev->id); ?>/reject" method="POST" style="display:inline"><?php echo csrf_field(); ?><button class="btn btn-sm btn-danger">Reject</button></form>
    </li>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<h4>Approved Events</h4>
<ul>
  <?php $__currentLoopData = $approved; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($ev->title); ?> (<?php echo e($ev->date); ?>)</li>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\college-event-system\resources\views/dashboards/admin.blade.php ENDPATH**/ ?>