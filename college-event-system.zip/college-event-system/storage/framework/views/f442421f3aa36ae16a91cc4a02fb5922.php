<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-body">
    <h3><?php echo e($event->title); ?></h3>
    <p><?php echo e($event->description); ?></p>
    <p><strong>Date:</strong> <?php echo e($event->date); ?> <strong>Time:</strong> <?php echo e($event->time); ?></p>
    <p><strong>Venue:</strong> <?php echo e($event->venue); ?></p>
    <p><strong>Seats:</strong> <?php echo e($event->seats_booked); ?>/<?php echo e($event->max_participants); ?></p>
    <?php if(auth()->guard()->check()): ?>
      <form method="POST" action="<?php echo e(route('events.register', $event->id)); ?>"><?php echo csrf_field(); ?><button class="btn btn-primary">Register</button></form>
    <?php else: ?>
      <a href="/login" class="btn btn-outline-primary">Login to register</a>
    <?php endif; ?>
    <hr>
  <a href="data:text/calendar;charset=utf8,BEGIN:VCALENDAR%0AVERSION:2.0%0AUID:<?php echo e(uniqid()); ?>%0ADTSTAMP:<?php echo e(now()->format('Ymd\THis\Z')); ?>%0ASUMMARY:<?php echo e(urlencode($event->title)); ?>%0ADTSTART;TZID=Asia/Karachi:<?php echo e($event->date); ?>T<?php echo e(str_replace(':','',$event->time)); ?>00%0ADTEND;TZID=Asia/Karachi:<?php echo e($event->date); ?>T<?php echo e(str_pad((int)substr($event->time,0,2)+1,2,'0',STR_PAD_LEFT)); ?><?php echo e(substr($event->time,3,2)); ?>00%0ALOCATION:<?php echo e(urlencode($event->venue)); ?>%0ADESCRIPTION:<?php echo e(urlencode($event->description)); ?>%0AEND:VEVENT%0AEND:VCALENDAR" download="event.ics" class="btn btn-sm btn-outline-secondary">Add to Calendar (.ics)</a>
  <a href="https://calendar.google.com/calendar/render?action=TEMPLATE&text=<?php echo e(urlencode($event->title)); ?>&dates=<?php echo e($event->date); ?>T<?php echo e(str_replace(':','',$event->time)); ?>00Z/<?php echo e($event->date); ?>T<?php echo e(str_pad((int)substr($event->time,0,2)+1,2,'0',STR_PAD_LEFT)); ?><?php echo e(substr($event->time,3,2)); ?>00Z&details=<?php echo e(urlencode($event->description)); ?>&location=<?php echo e(urlencode($event->venue)); ?>" target="_blank" class="btn btn-sm btn-outline-success">Google Calendar</a>
  <a href="https://outlook.live.com/calendar/0/deeplink/compose?subject=<?php echo e(urlencode($event->title)); ?>&body=<?php echo e(urlencode($event->description)); ?>&startdt=<?php echo e($event->date); ?>T<?php echo e($event->time); ?>&enddt=<?php echo e($event->date); ?>T<?php echo e(str_pad((int)substr($event->time,0,2)+1,2,'0',STR_PAD_LEFT)); ?>:<?php echo e(substr($event->time,3,2)); ?>&location=<?php echo e(urlencode($event->venue)); ?>" target="_blank" class="btn btn-sm btn-outline-primary">Outlook</a>
    <div class="mt-2">
      <span>Share:</span>
      <a target="_blank" href="https://wa.me/?text=<?php echo e(urlencode($event->title.' on '.$event->date)); ?>" onclick="fetch('<?php echo e(route('events.logShare', $event->id)); ?>', {method:'POST',headers:{'X-CSRF-TOKEN':'<?php echo e(csrf_token()); ?>','Content-Type':'application/json'},body:JSON.stringify({platform:'WhatsApp',message:'<?php echo e($event->title); ?> on <?php echo e($event->date); ?>'})});">WhatsApp</a> |
      <a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(urlencode(request()->fullUrl())); ?>" onclick="fetch('<?php echo e(route('events.logShare', $event->id)); ?>', {method:'POST',headers:{'X-CSRF-TOKEN':'<?php echo e(csrf_token()); ?>','Content-Type':'application/json'},body:JSON.stringify({platform:'Facebook',message:'<?php echo e($event->title); ?>'})});">Facebook</a> |
      <a target="_blank" href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo e(urlencode(request()->fullUrl())); ?>&title=<?php echo e(urlencode($event->title)); ?>" onclick="fetch('<?php echo e(route('events.logShare', $event->id)); ?>', {method:'POST',headers:{'X-CSRF-TOKEN':'<?php echo e(csrf_token()); ?>','Content-Type':'application/json'},body:JSON.stringify({platform:'LinkedIn',message:'<?php echo e($event->title); ?>'})});">LinkedIn</a>
    </div>
    <script>
    function logCalendarSync(type, url) {
      fetch('<?php echo e(route('events.logCalendar', $event->id)); ?>', {
        method:'POST',
        headers:{'X-CSRF-TOKEN':'<?php echo e(csrf_token()); ?>','Content-Type':'application/json'},
        body:JSON.stringify({calendar_type:type,calendar_url:url})
      });
    }
    </script>
  </div>
</div>

<?php if(auth()->guard()->check()): ?>
  <hr>
  <h4>Submit Multi-Aspect Review</h4>
  <form method="POST" action="<?php echo e(route('events.review', $event->id)); ?>">
    <?php echo csrf_field(); ?>
    <div class="row">
      <div class="col-md-3 mb-2">
        <label>Content</label>
        <select name="content_rating" class="form-control" required>
          <option value="">Select</option>
          <?php for($i=1; $i<=5; $i++): ?>
            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
          <?php endfor; ?>
        </select>
      </div>
      <div class="col-md-3 mb-2">
        <label>Organization</label>
        <select name="organization_rating" class="form-control" required>
          <option value="">Select</option>
          <?php for($i=1; $i<=5; $i++): ?>
            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
          <?php endfor; ?>
        </select>
      </div>
      <div class="col-md-3 mb-2">
        <label>Venue</label>
        <select name="venue_rating" class="form-control" required>
          <option value="">Select</option>
          <?php for($i=1; $i<=5; $i++): ?>
            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
          <?php endfor; ?>
        </select>
      </div>
      <div class="col-md-3 mb-2">
        <label>Speakers</label>
        <select name="speakers_rating" class="form-control" required>
          <option value="">Select</option>
          <?php for($i=1; $i<=5; $i++): ?>
            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
          <?php endfor; ?>
        </select>
      </div>
    </div>
    <div class="mb-2">
      <label>Comments</label>
      <textarea name="comments" class="form-control" maxlength="2000"></textarea>
    </div>
    <button type="submit" class="btn btn-primary btn-sm">Submit Review</button>
  </form>
  <form method="POST" action="<?php echo e(route('favorites.addEvent', $event->id)); ?>" class="mt-2">
    <?php echo csrf_field(); ?>
    <button class="btn btn-outline-success btn-sm">Add to Favorites</button>
  </form>
<?php endif; ?>

<hr>
<h4>Event Reviews (Multi-Aspect)</h4>
<div class="mb-2">
  <strong>Average Ratings:</strong>
  <ul>
    <li>Content: <?php echo e(number_format($avg['content'], 2) ?? 'N/A'); ?></li>
    <li>Organization: <?php echo e(number_format($avg['organization'], 2) ?? 'N/A'); ?></li>
    <li>Venue: <?php echo e(number_format($avg['venue'], 2) ?? 'N/A'); ?></li>
    <li>Speakers: <?php echo e(number_format($avg['speakers'], 2) ?? 'N/A'); ?></li>
  </ul>
</div>
<?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="border p-2 mb-2">
    <strong><?php echo e($review->user->name); ?></strong> <br>
    <span>Content: <?php echo e($review->content_rating); ?>, Organization: <?php echo e($review->organization_rating); ?>, Venue: <?php echo e($review->venue_rating); ?>, Speakers: <?php echo e($review->speakers_rating); ?></span><br>
    <small><?php echo e($review->created_at->diffForHumans()); ?></small>
    <p><?php echo e($review->comments); ?></p>
  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\college-event-system\resources\views/events/show.blade.php ENDPATH**/ ?>