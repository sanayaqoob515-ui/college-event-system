<?php $__env->startSection('content'); ?>
<h2>My Certificates</h2>
<ul>
<?php $__currentLoopData = $certs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>
	<?php if(!$c->fee_paid): ?>
		<form method="POST" action="<?php echo e(route('certificates.pay', $c->id)); ?>" style="display:inline">
			<?php echo csrf_field(); ?>
			<button class="btn btn-sm btn-warning">Pay Certificate Fee</button>
		</form>
		<span class="text-danger">(Fee not paid)</span>
	<?php else: ?>
		<a href='/storage/<?php echo e($c->certificate_url); ?>' target='_blank'>Certificate for Event <?php echo e($c->event_id); ?></a>
	<?php endif; ?>
</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\college-event-system\resources\views/certificates/my.blade.php ENDPATH**/ ?>