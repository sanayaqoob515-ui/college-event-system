@extends('layouts.app')
@section('content')
<h2>About Us</h2>
<p>This platform is designed to manage and promote college events, registrations, certificates, and more. It connects students, organizers, and administrators for a seamless event experience.</p>
@endsection
